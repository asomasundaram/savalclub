import requests
import urllib3
import time
import json
import os.path

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

auth_url = "https://www.strava.com/oauth/token"
activites_url = "https://www.strava.com/api/v3/athlete/activities"

payload = {
    'client_id': "115482",
    'client_secret': '581478c0b57b480332fb547b4fb76daa1a1a8f88',
    'refresh_token': 'ba1dd4536f3d6b2a66cbffe16a51c46c51289a08',
    'grant_type': "refresh_token",
    'f': 'json'
}


print("Requesting Token...\n")
res = requests.post(auth_url, data=payload, verify=False)
#print (res.json())
access_token = res.json()['access_token']

athlete_url = "https://www.strava.com/api/v3/athlete"
header = {'Authorization': 'Bearer ' + access_token}
athelete_ds = requests.get(athlete_url, headers=header, params={}).json()
#print (athelete_ds)
username = athelete_ds ['username']
athleteid = str(athelete_ds ['id']) 
print(athleteid)
firstname = athelete_ds ['firstname']
lastname = athelete_ds ['lastname']
dictionary = dict()
file_path = 'store/store.json'

if (os.path.exists(file_path)):
  with open(file_path, "r") as fo:
    dictionary= (json.load(fo))

dictionary[athleteid] = athelete_ds 

with open (file_path, "w") as file:
  json.dump(dictionary, file)

ep = round(int(time.time()))
header = {'Authorization': 'Bearer ' + access_token}
param = {'before':ep, 'page': 1, 'per_page': 2}
my_dataset = requests.get(activites_url, headers=header, params=param).json()
print(my_dataset)
