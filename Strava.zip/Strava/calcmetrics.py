import time
import os.path
import json
import requests
from datetime import datetime

def last_4_quarters_dates(reference_date):
    quarters = []
    start_mmdd = ['01-01', '04-01', '07-01', '10-01']
    end_mmdd = ['03-31', '06-30', '09-30', '12-31']

    current_quarter_no = int (reference_date.month / 3) + 1
    current_quarter_start_month = (current_quarter_no - 1) * 3 + 1
    current_year = reference_date.year


    # Calculate the last 4 quarters
    for i in range(4):
        current_quarter_start_date = str(current_year)+ "-" + start_mmdd [current_quarter_no - 1]
        current_quarter_end_date = str(current_year)+ "-" + end_mmdd [current_quarter_no - 1]
        start_date = datetime.strptime(current_quarter_start_date, "%Y-%m-%d")
        end_date = datetime.strptime(current_quarter_end_date, "%Y-%m-%d")
        quarters.append((start_date, end_date, current_quarter_no, current_year))
        current_quarter_no = current_quarter_no - 1

        if (current_quarter_no == 0):
            current_year = current_year - 1
            current_quarter_no = 4


    return quarters


def crunch_numbers(athlete_ds):

  auth_url = "https://www.strava.com/oauth/token"

  payload_refresh = {
        'client_id': "",
        'client_secret': '',
        'refresh_token': athlete_ds["refresh_token"],
        'grant_type': "refresh_token",
        'f': 'json'}
  res = requests.post(auth_url, data=payload_refresh, verify=False).json()
  access_token = res["access_token"]
  print ("access token " + access_token)

  ep = round(int(time.time()))

  start_mmdd = ['01-01', '04-01', '07-01', '10-01']
  end_mmdd = ['03-31', '06-30', '09-30', '12-31']
  current_date = datetime.now()
  quarter_dates = last_4_quarters_dates(current_date)

  for i, (start_date, end_date, current_quarter_no, current_year) in enumerate(quarter_dates):
    epoch_time_start = time.mktime(start_date.timetuple())
    epoch_time_end = time.mktime(end_date.timetuple())
    print (start_date)
    print (end_date)
    header = {'Authorization': 'Bearer ' + access_token}

    activites_url = "https://www.strava.com/api/v3/athlete/activities"

    param = {'before':epoch_time_end, 'after':epoch_time_start, 'page': 1, 'per_page': 100}
    
    activities_ds = requests.get(activites_url, headers=header, params=param).json()
    activities_count = len(activities_ds)
    #print(activities_ds[0])
    print ("Quarter No " + str(current_quarter_no))
    print('activities count ' + str(activities_count))

    act_no = 0
    distance = 0
    elev_gain=0
    moving_time = 0
    


    while (act_no < activities_count) :
      distance = distance + activities_ds[act_no]["distance"]
      elev_gain = elev_gain + activities_ds[act_no]["total_elevation_gain"]
      moving_time = moving_time + activities_ds[act_no]["moving_time"]
      act_no = act_no + 1

    print ("distance for quarter " + str(current_quarter_no) + " is " + str(round(distance * 0.000621371,2)) + " miles")
    print ("elev gain for quarter " + str(current_quarter_no) + " is " + str(round(elev_gain * 3.28084, 2)) + " ft")
    print ("moving time for quarter " + str(current_quarter_no) + " is " + str(round(moving_time/3600, 2)) + " hrs")
    print ("---------------------------------------------------------------------")
    metrics = {}
    metrics ["distance"] = round(distance * 0.000621371, 2)
    metrics ["elv_gain"] = round(elev_gain * 3.28084, 2)
    metrics ["moving_time"] = round(moving_time/3600, 2)
    k = str(current_year)+"-"+"Q"+str(current_quarter_no) ;
    athlete_ds [k] = metrics
    
dictionary = dict()
file_path = 'store/store.json'

if (os.path.exists(file_path)):
  with open(file_path, "r") as fo:
    dictionary= (json.load(fo))

for key in dictionary.keys():
  crunch_numbers(dictionary[key])

with open (file_path, "w") as file:
  json.dump(dictionary, file)