import requests
import urllib3
import time
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

auth_url = "https://www.strava.com/oauth/token"
#activites_url = "https://www.strava.com/api/v3/clubs/920379/activities"
activites_url = "https://www.strava.com/api/v3/athlete/activities"

payload = {
    'client_id': "115482",
    'client_secret': 'a8ba6d54854b7f6896290b38aad90032817fbe98',
    'refresh_token': 'ba1dd4536f3d6b2a66cbffe16a51c46c51289a08',
    'grant_type': "refresh_token",
    'f': 'json'
}

print("Requesting Token...\n")
res = requests.post(auth_url, data=payload, verify=False)
access_token = res.json()['access_token']
print("Access Token = {}\n".format(access_token))
#param = {'id':920379, 'per_page': 30, 'page': 2}
ep_time = round(int(time.time()))

header = {'Authorization': 'Bearer ' + access_token}
param = {'per_page': 1, 'page': 1}

my_dataset = requests.get(activites_url, headers=header, params=param).json()

print(my_dataset)
