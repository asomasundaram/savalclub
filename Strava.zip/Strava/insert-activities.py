import requests
import time
import json
import boto3

# fetch client_id, client_secret from secret.

def get_access_token(refresh_token):
    auth_url = "https://www.strava.com/oauth/token"

    payload_refresh = {
        'client_id': "xxxx",
        'client_secret': 'xxxxx',
        'refresh_token':refresh_token,
        'grant_type': "refresh_token",
        'f': 'json'}
    res = requests.post(auth_url, data=payload_refresh, verify=False).json()
    access_token = res["access_token"]
    print ("access token " + access_token)
    return access_token

def get_activities(access_token):
    # Get the current year
    current_year = time.localtime().tm_year

    # Create a string representing the first day of the year
    first_day_of_year_string = str(current_year) + '-01-01'

    # Convert the string to a timestamp
    timestamp = int(time.mktime(time.strptime(first_day_of_year_string, '%Y-%m-%d')))

    url = "https://www.strava.com/api/v3/athlete/activities"

    headers = {'Authorization': 'Bearer ' + access_token}

    # set the initial page number and activities list
    page_num = 1
    activities = []

    while True:
        params = {'per_page': 100, 'page': page_num, 'after': timestamp}
        response = requests.get(url, headers=headers, params=params, verify=False)

        if response.status_code == 200:
            page_activities = json.loads(response.content)
            if not page_activities:
                # if there are no more activities, break out of the loop
                break
            activities.extend(page_activities)
            page_num += 1
        else:
            print("Error fetching activities:", response.content)
            break

    print("Fetched", len(activities), "activities.")
    return activities


def store_activities_in_dynamodb (id, firstname, lastname, activities):
    try:
        # Create a new record in DynamoDB for the user with their metrics
 
        item = {
                'id': {'N': str(id)},

                'firstname': {'S': firstname},
                'lastname': {'S': lastname},
         }

        for key, value in metrics.items():
            if value is None:
                value = 0
            item[key] = {'N': str(value)}
        print(item)
        response = dynamodb.put_item(
            TableName="user-activities",
            Item=item
        )
        print(item)
        print(f"Stored activites in DynamoDB for user {id}")

    except Exception as e:
        print(f"Failed to store metrics in DynamoDB for user {id}: {str(e)}")
        traceback.print_exc()

def lambda_handler(event, context):
    # Initialize the DynamoDB client
    dynamodb = boto3.client('dynamodb')
    
    # Specify the table name
    table_name = 'saval-users'
    
    try:
        # Define the scan parameters
        athlete_ds={}
        scan_params = {
            'TableName': table_name,
            #'ProjectionExpression': 'firstname, refresh_token'
        }
    
        # Scan the DynamoDB table to retrieve all records with the specified attributes
        response = dynamodb.scan(**scan_params)
    
        # Check if there are any items in the response
        if 'Items' in response:
            # Iterate through each item and print the desired attributes
            for item in response['Items']:
                print("Record:"+str(item))
                # Extract the 'firstname' and 'refresh_token' attributes
                id = item.get('id', {}).get('N', 'N/A')
                firstname = item.get('firstname', {}).get('S', 'N/A')
                lastname = item.get('lastname', {}).get('S', 'N/A')
                refresh_token = item.get('refresh_token', {}).get('S', 'N/A')
                print(f"firstname: {firstname}")
                print(f"refresh_token: {refresh_token}")
                access_token=get_access_token(refresh_token)
                activities = get_activities(access_token)
                #(get_access_token(refresh_token))
                #quarterly_metrics = crunch_numbers(access_token)
                #print(quarterly_metrics)
                store_activities_in_dynamodb(id, firstname, lastname, quarterly_metrics)
        else:
            print("No records found in the DynamoDB table.")
    
    except Exception as e:
        print(f"An error occurred: {str(e)}")
