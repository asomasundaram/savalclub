from datetime import datetime

def last_4_quarters_dates(reference_date):
    quarters = []
    start_mmdd = ['01-01', '04-01', '07-01', '10-01']
    end_mmdd = ['03-31', '06-30', '09-30', '12-31']

    current_quarter_no = int (reference_date.month / 3) + 1
    current_quarter_start_month = (current_quarter_no - 1) * 3 + 1
    current_year = reference_date.year


    # Calculate the last 4 quarters
    for i in range(4):
        current_quarter_start_date = str(current_year)+ "-" + start_mmdd [current_quarter_no - 1]
        current_quarter_end_date = str(current_year)+ "-" + end_mmdd [current_quarter_no - 1]
        start_date = datetime.strptime(current_quarter_start_date, "%Y-%m-%d")
        end_date = datetime.strptime(current_quarter_end_date, "%Y-%m-%d") 
        quarters.append((start_date, end_date, current_quarter_no, current_year))
        current_quarter_no = current_quarter_no - 1

        if (current_quarter_no == 0):
            current_year = current_year - 1
            current_quarter_no = 4


    return quarters

# Get the last 4 quarters starting from the current date
current_date = datetime.now()
quarter_dates = last_4_quarters_dates(current_date)

for i, (start_date, end_date, current_quarter_no, current_year) in enumerate(quarter_dates):
    print(f"Year {current_year}:")
    print(f"Quarter {current_quarter_no}:")
    print(f"Start Date: {start_date.strftime('%Y-%m-%d')}")
    print(f"End Date: {end_date.strftime('%Y-%m-%d')}")
    print()