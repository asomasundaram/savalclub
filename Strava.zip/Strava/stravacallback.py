import json
import boto3
import requests
import os

def lambda_handler(event, context):
    print(event)
    print(context.aws_request_id)
    client_id = os.environ.get('CLIENT_ID')
    client_secret = os.environ.get('CLIENT_SECRET')
    dynamodb = boto3.resource('dynamodb')
    
    
    
    # api-endpoint
    URL = "https://www.strava.com/api/v3/"
      
    # data to be sent to api
    data = {'client_id':client_id,
        'client_secret':client_secret,
        'code':event['code'],
        'grant_type':'authorization_code'}
  
    # sending post request and saving response as response object
    r = requests.post(url = URL + "oauth/token", data = data)
      
    # extracting data in json format
    data = r.json()
    print(data)
    token= data['access_token']
    print(token)
    type=data['token_type']
    reqUrl = "https://www.strava.com/api/v3/athlete"
    
    headersList = {
     "Accept": "*/*",
     "Authorization": type + ' ' + token  
    }
    
    payload = ""
    
    response = requests.request("GET", URL + "athlete", data=payload,  headers=headersList)
    athlete = response.json()
    print("athlete =>")
    print(athlete)
    
    # Get a reference to the table
    table = dynamodb.Table('saval-users')
    
    print(athlete['id'])
    print(athlete['firstname'])
    print(athlete['lastname'])
    print(data['access_token'])
    print(data['refresh_token'])

    # Add the record to the table
    putresponse = table.put_item(
        Item={
            'id': athlete['id'],
            'firstname': athlete['firstname'],
            'lastname': athlete['lastname'],
            'sourcesystem': 'strava',
            'access_token': data['access_token'],
            'refresh_token': data['refresh_token'],
            'uid': event['uid']
        }
    )
    print(putresponse)
    htmlcontent = """
    <!DOCTYPE html>
    <html>
    <head>
        <style>
        /* Define CSS styles here */
        body {{
            background-image: url('https://saval-challenges-images.s3.us-west-2.amazonaws.com/cyclist-3202481_1280.jpg'); /* Replace 'background-image-url.jpg' with your image URL */
            background-size: cover;
            background-repeat: no-repeat;
            color: #fff; /* Text color */
            font-family: Arial, sans-serif;
        }}

        h1 {{
            font-size: 24px;
        }}

        /* Additional styles for other elements */
        </style>
    </head>
    <body>
        <h1>Thanks {fname} {lname} </h1>
        <p>You will receive notifications at {uid} with your progress against the challenge</p>
        <p>Request ID: {reqid}</p>

        <!-- Copyright and Privacy Policy section -->
        <footer>
        <p>&copy; 2023 Saval Givings Inc., All rights reserved.</p>
        <p><a href="privacy-policy.html">Privacy Policy</a></p>
        </footer>
    </body>
    </html>""".format(fname=athlete['firstname'], lname=athlete['lastname'], reqid=context.aws_request_id, uid=event['uid'])
    return {
        "statusCode": 200,
        "body": htmlcontent,
        "headers": {"Content-Type": "text/html"}
    }
