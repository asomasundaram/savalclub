/*
   * Create form to request access token from Google's OAuth 2.0 server.
   */


function oauth2SignIn() {
    // Google's OAuth 2.0 endpoint for requesting an access token
    var YOUR_CLIENT_ID = '11079587524-fh7q8igpn1ub4d9rkf6hejaco3f07gj2.apps.googleusercontent.com';
    var YOUR_REDIRECT_URI = 'https://saval-app.s3.us-west-2.amazonaws.com/Dashboard.html';

    var oauth2Endpoint = 'https://accounts.google.com/o/oauth2/v2/auth';

    var xhr_response = JSON.parse(localStorage.getItem('google_user'));
    console.log('Inside oauth2SignIn')


    // Create element to open OAuth 2.0 endpoint in new window.
    var form = document.createElement('form');
    form.setAttribute('method', 'GET'); // Send as a GET request.
    form.setAttribute('action', oauth2Endpoint);

    // Parameters to pass to OAuth 2.0 endpoint.
    var params = {
        'client_id': YOUR_CLIENT_ID,
        'redirect_uri': YOUR_REDIRECT_URI,
        'scope': 'email profile https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile openid',
        'state': 'get_google_profile',
        'include_granted_scopes': 'true',
        'response_type': 'token'
    };

    // Add form parameters as hidden input values.
    for (var p in params) {
        var input = document.createElement('input');
        input.setAttribute('type', 'hidden');
        input.setAttribute('name', p);
        input.setAttribute('value', params[p]);
        form.appendChild(input);
    }

    // Add form to page and submit it to open the OAuth 2.0 endpoint.
    document.body.appendChild(form);
    form.submit();
}


// If there's an access token, try an API request.
// Otherwise, start OAuth 2.0 flow.
function getGoogleProfile() {

    var xhr_response = JSON.parse(localStorage.getItem('google_user'));


    var params = JSON.parse(localStorage.getItem('google-oauth2-params'));
    if (params && params['access_token']) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET',
            'https://www.googleapis.com/oauth2/v2/userinfo?' +
            'access_token=' + params['access_token']);
        xhr.onreadystatechange = function (e) {
            if (xhr.readyState === 4 && xhr.status === 200) {
                let info = JSON.parse(xhr.response)
                document.getElementById("name").innerHTML = "Hello " + info['name']
                getStravaData (info['email'])
                localStorage.setItem('google_user', xhr.response)
            } else if (xhr.readyState === 4 && xhr.status === 401) {
                // Token invalid, so prompt for user permission.
                localStorage.removeItem('google_user')
                oauth2SignIn();
            }
        };
        xhr.send(null);
    } else {
        oauth2SignIn();
    }
}



function getStravaData(email) {

    const apiUrl = 'https://api.saval.org';
    const endpoint = '/getStravaUser';
    const parameters = {
        gmail: email,
    };

    // Convert the parameters object to a query string
    const queryString = Object.keys(parameters)
        .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(parameters[key])}`)
        .join('&');

    // Construct the full URL with parameters
    const urlWithParameters = `${apiUrl}${endpoint}?${queryString}`;
    console.log (urlWithParameters)

    // Make the GET request
    fetch(urlWithParameters, {
        mode : 'cors',
        method: 'GET',
        headers: {
            'Content-Type': 'application/json', // adjust as needed
            // Add any other headers if required
        },
    })
        .then(response => response.json())
        .then(data => {
            console.log('Response data:', data);

            if (data.Items.length > 0)
            {
                document.getElementById("name").innerHTML = "Welcome " + data.Items[0].firstname + " " + data.Items[0].lastname
                localStorage.setItem('strava_user', JSON.stringify(data))
                displayMetrics(data.Items[0].id)
            }
            else
            {
                var x = document.getElementById("strava_button") 
                x.style.display = "block"
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });

}



function displayMetrics(id) {

    const apiUrl = 'https://api.saval.org';
    const endpoint = '/getStravaMetrics';
    const parameters = {
        athleteid: id,
    };

    // Convert the parameters object to a query string
    const queryString = Object.keys(parameters)
        .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(parameters[key])}`)
        .join('&');

    // Construct the full URL with parameters
    const urlWithParameters = `${apiUrl}${endpoint}?${queryString}`;
    console.log (urlWithParameters)

    // Make the GET request
    fetch(urlWithParameters, {
        mode : 'cors',
        method: 'GET',
        headers: {
            'Content-Type': 'application/json', // adjust as needed
            // Add any other headers if required
        },
    })
        .then(response => response.json())
        .then(info => {
            console.log('Response data:', info);

            document.getElementById("2023_Q1_activity_count").innerHTML=info.Items[0]["2023_Q1_activity_count"]
            document.getElementById("2023_Q1_distance").innerHTML=info.Items[0]["2023_Q1_distance"]
            document.getElementById("2023_Q1_elv_gain").innerHTML=info.Items[0]["2023_Q1_elv_gain"]
            document.getElementById("2023_Q1_moving_time").innerHTML=info.Items[0]["2023_Q1_moving_time"]

            document.getElementById("2023_Q2_activity_count").innerHTML=info.Items[0]["2023_Q2_activity_count"]
            document.getElementById("2023_Q2_distance").innerHTML=info.Items[0]["2023_Q2_distance"]
            document.getElementById("2023_Q2_elv_gain").innerHTML=info.Items[0]["2023_Q2_elv_gain"]
            document.getElementById("2023_Q2_moving_time").innerHTML=info.Items[0]["2023_Q2_moving_time"]
            
            document.getElementById("2023_Q3_activity_count").innerHTML=info.Items[0]["2023_Q3_activity_count"]
            document.getElementById("2023_Q3_distance").innerHTML=info.Items[0]["2023_Q3_distance"]
            document.getElementById("2023_Q3_elv_gain").innerHTML=info.Items[0]["2023_Q3_elv_gain"]
            document.getElementById("2023_Q3_moving_time").innerHTML=info.Items[0]["2023_Q3_moving_time"]
            
            document.getElementById("2023_Q4_activity_count").innerHTML=info.Items[0]["2023_Q4_activity_count"]
            document.getElementById("2023_Q4_distance").innerHTML=info.Items[0]["2023_Q4_distance"]
            document.getElementById("2023_Q4_elv_gain").innerHTML=info.Items[0]["2023_Q4_elv_gain"]
            document.getElementById("2023_Q4_moving_time").innerHTML=info.Items[0]["2023_Q4_moving_time"]
            
            
        })
        .catch(error => {
            console.error('Error:', error);
        });

}


function startStravaOauth(){


    const isInStorage = str => localStorage.getItem(str) !== null;
    console.log('startStravaOauth : checking google_user')

    if (isInStorage("google_user")) {
      console.log('google_user_present')
      var profile_data = JSON.parse(localStorage.getItem('google_user'));
      strava_url = "https://www.strava.com/oauth/authorize?client_id=115911&response_type=code&redirect_uri=https://api.saval.org/exchange_token/"+ profile_data['email'] + "&approval_prompt=force&scope=read,activity:read"
      window.open(strava_url,'_blank')
    }
}
