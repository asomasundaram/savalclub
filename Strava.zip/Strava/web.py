from flask import Flask, render_template, request, make_response
from flask_cors import CORS, cross_origin

import pickle 
import requests
import urllib3
import time
import os.path
import json

app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'

@app.route("/")
def home():
    response = make_response(render_template('Login9.html'))
    response.headers["Referrer-Policy"] = 'no-referrer'
    return response
     


@app.route("/exchange_token", methods=['GET','POST'])
def exchange_token():
    if request.method == 'GET':
        #access the data from form
        ## Age
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        code = request.args.get('code')
        #return render_template("index.html", prediction_text='Your code is {}'.format(token))
        auth_url = "https://www.strava.com/oauth/token"

        payload = {
        'client_id': "115482",
        'client_secret': '581478c0b57b480332fb547b4fb76daa1a1a8f88',
        'code': code,
        'grant_type': "authorization_code",
        'f': 'json'
        }

        #payload_refresh = {
        #'client_id': "115482",
        #'client_secret': 'a8ba6d54854b7f6896290b38aad90032817fbe98',
        #'refresh_token': '2a6b8a7146522a3dfa28c7a6d98b187740bbe6bb',
        #'grant_type': "refresh_token",
        #'f': 'json'}
        #res = requests.post(auth_url, data=payload_refresh, verify=False)

        #############  Get Access token from one time code

        res = requests.post(auth_url, data=payload, verify=False)

        a_token = res.json()['access_token']
        r_token = res.json()['refresh_token']
        name = res.json()['athlete']['firstname']

        #############  Get Athlete 


        athlete_url = "https://www.strava.com/api/v3/athlete"
        header = {'Authorization': 'Bearer ' + a_token}
        athelete_ds = requests.get(athlete_url, headers=header, params={}).json()
        athleteid = str(athelete_ds ['id']) 
        #print (athelete_ds)
        dictionary = dict()
        file_path = 'store/store.json'

        if (os.path.exists(file_path)):
          with open(file_path, "r") as fo:
            dictionary= (json.load(fo))
        
        metrics = {}

        if (athleteid not in dictionary) :
          print ("adding to store")
          athelete_ds["refresh_token"] = r_token
          athelete_ds["access_token"] = a_token
          dictionary[athleteid] = athelete_ds 
        else :
          store_ds = dictionary[athleteid]
          store_ds["refresh_token"] = r_token
          store_ds["access_token"] = a_token
          dictionary[athleteid] = store_ds
          metrics =  dictionary[athleteid]["2023-Q4"]


        with open (file_path, "w") as file:
          json.dump(dictionary, file)

        ############ Get Activity

        activites_url = "https://www.strava.com/api/v3/athlete/activities"
        ep = round(int(time.time()))
        header = {'Authorization': 'Bearer ' + a_token}
        param = {'before':ep, 'page': 1, 'per_page': 1}
        act_dataset = requests.get(activites_url, headers=header, params=param).json()
        print (metrics)


        return render_template("index.html", access_token='Your access token is {}'.format(a_token), 
        refresh_token='Your refresh token is {}'.format(r_token),
        username='Hello {}'.format(name),
        activity_name='Your recent activitiy is {}'.format(act_dataset[0]['name']+ ' at ' + act_dataset[0]['start_date']),
        data = metrics)




if __name__ == "__main__":
    app.run( debug=True)